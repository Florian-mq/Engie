﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Capgemini
{
    public class Fuels
    {
        [JsonProperty("gas(euro/MWh)")]
        public double GasEuroMWh { get; set; }

        [JsonProperty("kerosine(euro/MWh)")]
        public double KerosineEuroMWh { get; set; }

        [JsonProperty("co2(euro/ton)")]
        public double Co2EuroTon { get; set; }

        [JsonProperty("wind(%)")]
        public double Wind { get; set; }
    }

    public class Powerplant
    {
        public string name { get; set; }
        public string type { get; set; }
        public double efficiency { get; set; }
        public double pmin { get; set; }
        public double pmax { get; set; }
    }

    public class Root
    {
        public double load { get; set; }
        public Fuels fuels { get; set; }
        public List<Powerplant> powerplants { get; set; }
    }

    public class Data
    {
        public String name;
        public double p;

        public Data(String name, double p)
        {
            this.name = name;
            this.p = p;
        }
    }
    class Program
    {
        public static Computation GetDataFromJSonFile(String filename)
        {
            using (StreamReader r = new StreamReader(filename))
            {
                string json = r.ReadToEnd();
                Root root = JsonConvert.DeserializeObject<Root>(json);
                int count = root.powerplants.Count;
                Computation c = new Computation(count);
                c.goal = root.load;
                for (int i = 0; i < count; i++)
                {
                    switch (root.powerplants[i].type)
                    {
                        case ("gasfired"):
                            c.cost[i] = root.fuels.GasEuroMWh;
                            break;
                        case ("turbojet"):
                            c.cost[i] = root.fuels.Co2EuroTon;
                            break;
                        default:
                            c.cost[i] = 0;
                            break;
                    }
                    c.min[i] = root.powerplants[i].efficiency * root.powerplants[i].pmin;
                    c.max[i] = root.powerplants[i].efficiency * root.powerplants[i].pmax;
                    if (root.powerplants[i].type.Equals("windturbine"))
                    {
                        c.min[i] *= root.fuels.Wind / 100;
                        c.max[i] *= root.fuels.Wind / 100;
                    }
                    c.name[i] = root.powerplants[i].name;
                }
                return c;
            }
        }

        public static void CreateJSonFile(Computation c, double[] result)
        {
            Data[] array = new Data[result.Length];
            for (int i = 0; i < result.Length; i++)
            {
                array[i] = new Data(c.name[i], result[i]);
            }
            string json = JsonConvert.SerializeObject(array);
            System.IO.File.WriteAllText("response.json", json);
        }

        public static void Main(string[] args)
        {
            Computation c = GetDataFromJSonFile("payload1.json");
            double[] result = Computation.Compute(c);
            CreateJSonFile(c, result);
        }
    }
}
