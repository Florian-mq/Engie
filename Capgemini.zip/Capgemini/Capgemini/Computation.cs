﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capgemini
{
    class Computation
    {
        public double[] cost;
        public double[] min;
        public double[] max;
        public double goal;
        public String[] name;

        public Computation(int count)
        {
            this.cost = new double[count];
            this.min = new double[count];
            this.max = new double[count];
            this.name = new String[count];
        }

        // we assume the arrays cost, min and max have the same length
        // we assume min[i] <= max[i] for all i
        // this function return an array l of the same length as cost, min and max
        // the output l it is such that :
        // l[i] = 0 or min[i] <= arr[i] <= max[i] for all i
        // the sum l[i] over i is equal to goal
        // the sum cost[i]*l[i] over i is minimal
        public static double[] Compute(Computation c)
        {
            int[] permutation = GiveReorderingList(c.cost);
            List<double[]> solution = new List<double[]>();
            for (int i = 0; i < Math.Pow(2, c.cost.Length); i++)
            {
                int[] array = ConvertBinaryToArray(i, c.cost.Length);
                for (int j = 0; j < c.cost.Length; j++)
                {
                    double total = 0;
                    double[] l = new double[c.cost.Length];
                    for (int k = 0; k < j; k++)
                    {
                        l[k] = c.max[permutation[k]] * array[k];
                        total += l[k];
                    }
                    for (int k = j + 1; k < c.cost.Length; k++)
                    {
                        l[k] = c.min[permutation[k]] * array[k];
                        total += l[k];
                    }
                    l[j] = c.goal - total;
                    if (c.min[permutation[j]] <= l[j] && l[j] <= c.max[permutation[j]])
                    {
                        solution.Add(l);
                    }
                }
            }
            return FindBestSolution(solution, c.cost);
        }

        public static double[] FindBestSolution(List<double[]> solution, double[] cost)
        {
            int[] permutation = GiveReorderingList(cost);
            double minValue = Double.MaxValue;
            int index = -1;
            for (int i = 0; i < solution.Count; i++)
            {
                double sum = 0;
                for (int j = 0; j < cost.Length; j++)
                {
                    sum += cost[permutation[j]] * solution[i][j];
                }
                if (sum < minValue)
                {
                    minValue = sum;
                    index = i;
                }
            }
            return solution[index];
        }

        public static int[] ConvertBinaryToArray(int n, int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = n % 2;
                n /= 2;
            }
            return array;
        }

        public static int[] GiveReorderingList(double[] array)
        {
            double[] copy = Copy(array);
            int[] permutation = IdentityPermutation(array.Length);
            int j = 1;
            while (j < copy.Length)
            {
                int i = j;
                while (i > 0 && copy[i - 1] > copy[i])
                {
                    SwitchElements(copy, i - 1, i);
                    SwitchElements(permutation, i - 1, i);
                    i--;
                }
                j++;
            }
            return permutation;
        }

        public static double[] Copy(double[] array)
        {
            double[] copy = new double[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                copy[i] = array[i];
            }
            return copy;
        }

        public static int[] IdentityPermutation(int n)
        {
            int[] identity = new int[n];
            for (int i = 0; i < n; i++)
            {
                identity[i] = i;
            }
            return identity;
        }

        public static void SwitchElements(int[] array, int e1, int e2)
        {
            int temp = array[e1];
            array[e1] = array[e2];
            array[e2] = temp;
        }

        public static void SwitchElements(double[] array, int e1, int e2)
        {
            double temp = array[e1];
            array[e1] = array[e2];
            array[e2] = temp;
        }
    }
}
